def calculate():
    """
    calculates the total
    :return: None
    """
    price = 15.75
    quantity = 3  # TODO change quantity to 5
    print(f'Total: {price * quantity}')


if __name__ == '__main__':
    calculate()
